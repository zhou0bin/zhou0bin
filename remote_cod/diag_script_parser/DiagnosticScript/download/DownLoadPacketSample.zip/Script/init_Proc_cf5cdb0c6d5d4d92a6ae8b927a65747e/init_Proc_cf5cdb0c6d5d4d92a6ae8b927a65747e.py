#Procedure.Title:
#Procedure.GUID:Proc_cf5cdb0c6d5d4d92a6ae8b927a65747e
#Procedure.Creator:GAC
#Procedure. EditHistoryList
# GAC 2021-11-16 16:43:33 creat dcument V1.0
import os
import sys
sys.path[0]=(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from enum import Enum
from goto import with_goto
import time
import json
from libs.appAPI.LibraryFun import *
from libs.communication.pdu_logical_link import PDUOpenChannel,PDUCloseChannel 
from libs.util.DiagLog import PrintLogInfo as WriteLog
from libs.util.dserver.odx_system import *
SRS_DtObj = ecuDtObj("A18M_SRS",0x710,0x790,1,"string","BsVar_11320477220c42189d5a8ca3bf09400e","false",0,"ecuDtObj",None)
srs_Active_status = False
SRS = LAS("$0SR7","string","BsVar_1123c277220c42189d5a8ca3bf09400e","$0SR7",0,"LAS","")
VciResult = ""
StatStep_StartCom = StatStep(1,"Start com Failed","启动通讯失败",True,False,"string","BsVar_2343c277720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_DefaultSession = StatStep(2,"default session Failed","返回默认模式失败",True,False,"string","BsVar_2343c273720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_FactoryModeRead = StatStep(3,"Factory Mode read Failed","工厂模式读取失败",True,False,"string","BsVar_2356c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_FactoryModeCheck = StatStep(4,"Factory Mode check Failed","工厂模式检测失败",True,False,"string","BsVar_2343c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_WriteVIN = StatStep(5,"write vin Failed","写入VIN失败",True,False,"string","BsVar_1593c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_ReadVIN = StatStep(6,"read vin Failed","读取VIN失败",True,False,"string","BsVar_1752c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_CheckVIN = StatStep(7,"check vin Failed","检查VIN失败",True,False,"string","BsVar_2391c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_WriteMTOC = StatStep(8,"write mtoc Failed","写入MTOC失败",True,False,"string","BsVar_1921c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_ReadMTOC = StatStep(9,"read mtoc failed","读取MTOC失败",True,False,"string","BsVar_3352c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_CheckMTOC = StatStep(10,"check mtoc  Failed","检查MTOC失败",True,False,"string","BsVar_3583c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_Writ0202 = StatStep(11,"write 0202 Failed","写入0202失败",True,False,"string","BsVar_2921c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_Read0202 = StatStep(12,"read 0202 failed","读取0202失败",True,False,"string","BsVar_4352c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_Check0202 = StatStep(13,"check 0202 Failed","比对0202失败",True,False,"string","BsVar_5583c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_Writ0204 = StatStep(14,"write 0204 Failed","写入0204失败",True,False,"string","BsVar_6921c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_Read0204 = StatStep(15,"read 0204 failed","读取0204失败",True,False,"string","BsVar_7352c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
StatStep_Check0204 = StatStep(16,"check 0204 Failed","清除0204失败失败",True,False,"string","BsVar_8583c275720c42189d5a8ca3bf09400e","",0,"StatStep",None)
def StartCom_f54b8cb17e5b457483a0a84658e5c0de(ECU,StatStepExcute):
	WriteLog("Excute StartCom_f54b8cb17e5b457483a0a84658e5c0de" + " ECU = " + GeneratedParameterType(ECU) + ", StatStepExcute = " + GeneratedParameterType(StatStepExcute))
	[IsExcuteSuccessful,VciResult,StpResult]=StartCom(ECU,StatStepExcute)
	return [IsExcuteSuccessful,VciResult,StpResult]

def CheckFactoryMode_9080ff07c28845d2bff755dbd58689b4(ECU,TargetValue,StatStepRead,StatStepCheck):
	WriteLog("Excute CheckFactoryMode_9080ff07c28845d2bff755dbd58689b4" + " ECU = " + GeneratedParameterType(ECU) + ", TargetValue = " + GeneratedParameterType(TargetValue) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsReadSuccessful,IsCheckSuccessful,VciResult,StpResult]=CheckFactoryMode(ECU,TargetValue,StatStepRead,StatStepCheck)
	return [IsReadSuccessful,IsCheckSuccessful,VciResult,StpResult]

def ExcuteServiceAndCheckResponse_16c35e5710524646991bf6fb71c31809(ECU,RequestString,TargetResponseString,StatStepExcute,StatStepCheck):
	WriteLog("Excute ExcuteServiceAndCheckResponse_16c35e5710524646991bf6fb71c31809" + " ECU = " + GeneratedParameterType(ECU) + ", RequestString = " + GeneratedParameterType(RequestString) + ", TargetResponseString = " + GeneratedParameterType(TargetResponseString) + ", StatStepExcute = " + GeneratedParameterType(StatStepExcute) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsExcuteSuccessful,IsCheckSuccessful,VciResult,StpResult]=ExcuteServiceAndCheckResponse(ECU,RequestString,TargetResponseString,StatStepExcute,StatStepCheck)
	return [IsExcuteSuccessful,IsCheckSuccessful,VciResult,StpResult]

def WriteAndCheckVIN_affcbdbb64444285aa34a35a398b6efd(ECU,VINValue,StatStepWrite,StatStepRead,StatStepCheck):
	WriteLog("Excute WriteAndCheckVIN_affcbdbb64444285aa34a35a398b6efd" + " ECU = " + GeneratedParameterType(ECU) + ", VINValue = " + GeneratedParameterType(VINValue) + ", StatStepWrite = " + GeneratedParameterType(StatStepWrite) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsWriteSuccessful,IsReadSuccessful,IsCheckSuccessful,VciResultWrite,VciResultRead,StpResult]=WriteAndCheckVIN(ECU,VINValue,StatStepWrite,StatStepRead,StatStepCheck)
	return [IsWriteSuccessful,IsReadSuccessful,IsCheckSuccessful,VciResultWrite,VciResultRead,StpResult]

def WriteAndCheckMTOC_8ffcbdbb64444285aa34a35a398b6efd(ECU,MTOCValue,StatStepWrite,StatStepRead,StatStepCheck):
	WriteLog("Excute WriteAndCheckMTOC_8ffcbdbb64444285aa34a35a398b6efd" + " ECU = " + GeneratedParameterType(ECU) + ", MTOCValue = " + GeneratedParameterType(MTOCValue) + ", StatStepWrite = " + GeneratedParameterType(StatStepWrite) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsWriteSuccessful,IsReadSuccessful,IsCheckSuccessful,VciResultWrite,VciResultRead,StpResult]=WriteAndCheckMTOC(ECU,MTOCValue,StatStepWrite,StatStepRead,StatStepCheck)
	return [IsWriteSuccessful,IsReadSuccessful,IsCheckSuccessful,VciResultWrite,VciResultRead,StpResult]

def CheckVIN_fd617c1679e34a7890fbc8dbcc6957d4(ECU,VINValue,StatStepRead,StatStepCheck):
	WriteLog("Excute CheckVIN_fd617c1679e34a7890fbc8dbcc6957d4" + " ECU = " + GeneratedParameterType(ECU) + ", VINValue = " + GeneratedParameterType(VINValue) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsReadSuccessful,IsCheckSuccessful,VciResultRead,StpResult]=CheckVIN(ECU,VINValue,StatStepRead,StatStepCheck)
	return [IsReadSuccessful,IsCheckSuccessful,VciResultRead,StpResult]

def CheckMTOC_8d617c1679e34a7890fbc8dbcc6957d4(ECU,MTOCValue,StatStepRead,StatStepCheck):
	WriteLog("Excute CheckMTOC_8d617c1679e34a7890fbc8dbcc6957d4" + " ECU = " + GeneratedParameterType(ECU) + ", MTOCValue = " + GeneratedParameterType(MTOCValue) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsReadSuccessful,IsCheckSuccessful,VciResultRead,StpResult]=CheckMTOC(ECU,MTOCValue,StatStepRead,StatStepCheck)
	return [IsReadSuccessful,IsCheckSuccessful,VciResultRead,StpResult]

def WriteAndCheckConfig_eb23f65f5c004df88e8159dfd0b4a96d(ECU,DID,ConfigValue,StatStepWrite,StatStepRead,StatStepCheck):
	WriteLog("Excute WriteAndCheckConfig_eb23f65f5c004df88e8159dfd0b4a96d" + " ECU = " + GeneratedParameterType(ECU) + ", DID = " + GeneratedParameterType(DID) + ", ConfigValue = " + GeneratedParameterType(ConfigValue) + ", StatStepWrite = " + GeneratedParameterType(StatStepWrite) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsWriteSuccessful,IsReadSuccessful,IsCheckSuccessful,VciResultWrite,VciResultRead,StpResult]=WriteAndCheckConfig(ECU,DID,ConfigValue,StatStepWrite,StatStepRead,StatStepCheck)
	return [IsWriteSuccessful,IsReadSuccessful,IsCheckSuccessful,VciResultWrite,VciResultRead,StpResult]

def CheckConfig_6938869395684dff93e85001e647f001(ECU,DID,ConfigValue,StatStepRead,StatStepCheck):
	WriteLog("Excute CheckConfig_6938869395684dff93e85001e647f001" + " ECU = " + GeneratedParameterType(ECU) + ", DID = " + GeneratedParameterType(DID) + ", ConfigValue = " + GeneratedParameterType(ConfigValue) + ", StatStepRead = " + GeneratedParameterType(StatStepRead) + ", StatStepCheck = " + GeneratedParameterType(StatStepCheck))
	[IsReadSuccessful,IsCheckSuccessful,VciResultRead,StpResult]=CheckConfig(ECU,DID,ConfigValue,StatStepRead,StatStepCheck)
	return [IsReadSuccessful,IsCheckSuccessful,VciResultRead,StpResult]

def DefaultSession_41a8bb88f07f49f783d906d1dfd1d995(ECU,StatStepExcute):
	WriteLog("Excute DefaultSession_41a8bb88f07f49f783d906d1dfd1d995" + " ECU = " + GeneratedParameterType(ECU) + ", StatStepExcute = " + GeneratedParameterType(StatStepExcute))
	[IsExcuteSuccessful,VciResult,StpResult]=DefaultSession(ECU,StatStepExcute)
	return [IsExcuteSuccessful,VciResult,StpResult]

StepResult=Enum('StepResult',('Ok','Nok','Cancel','None'))
@with_goto
def main():
	PDUOpenChannel()
	label.Stp_f54b8cb17e5b457483a0a84658e5c0de
	if(Evaluate('0SR7')):
		[UnneededOutParam,VciResult,StpResult]= StartCom_f54b8cb17e5b457483a0a84658e5c0de(SRS_DtObj,StatStep_StartCom)
		if(StpResult==StepResult.Ok):
			goto.Stp_9080ff07c28845d2bff755dbd58689b4
		if(StpResult==StepResult.Nok):
			goto.Stp_41a8bb88f07f49f783d906d1dfd1d995
	label.Stp_9080ff07c28845d2bff755dbd58689b4
	[UnneededOutParam,UnneededOutParam,VciResult,StpResult]= CheckFactoryMode_9080ff07c28845d2bff755dbd58689b4(SRS_DtObj,'00000000',StatStep_FactoryModeRead,StatStep_FactoryModeCheck)
	label.Stp_16c35e5710524646991bf6fb71c31809
	[UnneededOutParam,srs_Active_status,UnneededOutParam,StpResult]= ExcuteServiceAndCheckResponse_16c35e5710524646991bf6fb71c31809(SRS_DtObj,'220202','620202FF',None,None)
	label.Stp_55368cb17e5b457483a0a84658e5c0de
	if(srs_Active_status):
		label.Stp_affcbdbb64444285aa34a35a398b6efd
		if(srs_Active_status):
			[UnneededOutParam,UnneededOutParam,UnneededOutParam,UnneededOutParam,UnneededOutParam,StpResult]= WriteAndCheckVIN_affcbdbb64444285aa34a35a398b6efd(SRS_DtObj,'LMGKT1A003S100001',StatStep_WriteVIN,StatStep_ReadVIN,StatStep_CheckVIN)
		label.Stp_8ffcbdbb64444285aa34a35a398b6efd
		if(srs_Active_status):
			[UnneededOutParam,UnneededOutParam,UnneededOutParam,UnneededOutParam,UnneededOutParam,StpResult]= WriteAndCheckMTOC_8ffcbdbb64444285aa34a35a398b6efd(SRS_DtObj,'KT1A-0W8-00',StatStep_WriteMTOC,StatStep_ReadMTOC,StatStep_CheckMTOC)
		label.Stp_fd617c1679e34a7890fbc8dbcc6957d4
		if(srs_Active_status):
			[UnneededOutParam,UnneededOutParam,UnneededOutParam,StpResult]= CheckVIN_fd617c1679e34a7890fbc8dbcc6957d4(SRS_DtObj,'LMGKT1A003S100001',StatStep_ReadVIN,StatStep_CheckVIN)
		label.Stp_8d617c1679e34a7890fbc8dbcc6957d4
		if(srs_Active_status):
			[UnneededOutParam,UnneededOutParam,UnneededOutParam,StpResult]= CheckMTOC_8d617c1679e34a7890fbc8dbcc6957d4(SRS_DtObj,'KT1A-0W8-00',StatStep_ReadMTOC,StatStep_CheckMTOC)
		label.Stp_eb23f65f5c004df88e8159dfd0b4a96d
		if(srs_Active_status):
			[UnneededOutParam,UnneededOutParam,UnneededOutParam,UnneededOutParam,UnneededOutParam,StpResult]= WriteAndCheckConfig_eb23f65f5c004df88e8159dfd0b4a96d(SRS_DtObj,'0202','00',StatStep_Writ0202,StatStep_Read0202,StatStep_Check0202)
		label.Stp_6938869395684dff93e85001e647f001
		if(srs_Active_status):
			[UnneededOutParam,UnneededOutParam,UnneededOutParam,StpResult]= CheckConfig_6938869395684dff93e85001e647f001(SRS_DtObj,'0202','00',StatStep_Read0202,StatStep_Check0202)
	label.Stp_41a8bb88f07f49f783d906d1dfd1d995
	[UnneededOutParam,VciResult,StpResult]= DefaultSession_41a8bb88f07f49f783d906d1dfd1d995(SRS_DtObj,StatStep_DefaultSession)
	PDUCloseChannel()
if ( __name__ == "__main__"):
	main()